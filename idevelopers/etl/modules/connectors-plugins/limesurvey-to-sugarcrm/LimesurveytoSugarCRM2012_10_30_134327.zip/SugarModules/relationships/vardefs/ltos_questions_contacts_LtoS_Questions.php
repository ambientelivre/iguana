<?php
// created: 2012-10-30 13:43:27
$dictionary["LtoS_Questions"]["fields"]["ltos_questions_contacts"] = array (
  'name' => 'ltos_questions_contacts',
  'type' => 'link',
  'relationship' => 'ltos_questions_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_LTOS_QUESTIONS_CONTACTS_FROM_CONTACTS_TITLE',
  'id_name' => 'ltos_questions_contactscontacts_ida',
);
$dictionary["LtoS_Questions"]["fields"]["ltos_questions_contacts_name"] = array (
  'name' => 'ltos_questions_contacts_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_LTOS_QUESTIONS_CONTACTS_FROM_CONTACTS_TITLE',
  'save' => true,
  'id_name' => 'ltos_questions_contactscontacts_ida',
  'link' => 'ltos_questions_contacts',
  'table' => 'contacts',
  'module' => 'Contacts',
  'rname' => 'name',
  'db_concat_fields' => 
  array (
    0 => 'first_name',
    1 => 'last_name',
  ),
);
$dictionary["LtoS_Questions"]["fields"]["ltos_questions_contactscontacts_ida"] = array (
  'name' => 'ltos_questions_contactscontacts_ida',
  'type' => 'link',
  'relationship' => 'ltos_questions_contacts',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_LTOS_QUESTIONS_CONTACTS_FROM_LTOS_QUESTIONS_TITLE',
);
