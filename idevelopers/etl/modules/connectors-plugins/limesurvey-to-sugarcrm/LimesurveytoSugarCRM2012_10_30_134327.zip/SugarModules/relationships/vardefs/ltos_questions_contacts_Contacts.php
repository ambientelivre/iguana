<?php
// created: 2012-10-30 13:43:27
$dictionary["Contact"]["fields"]["ltos_questions_contacts"] = array (
  'name' => 'ltos_questions_contacts',
  'type' => 'link',
  'relationship' => 'ltos_questions_contacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_LTOS_QUESTIONS_CONTACTS_FROM_LTOS_QUESTIONS_TITLE',
);
