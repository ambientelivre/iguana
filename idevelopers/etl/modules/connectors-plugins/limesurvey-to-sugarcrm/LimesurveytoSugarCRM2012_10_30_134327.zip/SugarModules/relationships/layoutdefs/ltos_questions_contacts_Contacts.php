<?php
 // created: 2012-10-30 13:43:27
$layout_defs["Contacts"]["subpanel_setup"]['ltos_questions_contacts'] = array (
  'order' => 100,
  'module' => 'LtoS_Questions',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_LTOS_QUESTIONS_CONTACTS_FROM_LTOS_QUESTIONS_TITLE',
  'get_subpanel_data' => 'ltos_questions_contacts',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
